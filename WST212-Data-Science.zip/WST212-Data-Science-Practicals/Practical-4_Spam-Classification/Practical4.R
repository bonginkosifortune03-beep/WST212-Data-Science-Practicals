########################
# Practical 4
# Name and surname: Maima Bonginkosi Fortune
# Student number: u22826093
########################

# Load the necessary packages
# DO NOT IMPORT ANY OTHER PACKAGES
library(caret)

# Import the tables

spam <- read.csv("spam_msgs_b0.csv")


# Question 1

#Step1:conveting my categorical to factor
spam$is_spam<-ifelse(spam$is_spam=="ham",0,1)
spam$is_spam=factor(spam$is_spam)
spam$has_numbers<-factor(spam$has_numbers)
spam$has_url<-factor(spam$has_url)
spam$has_date<-factor(spam$has_date)
spam$has_dollar<-factor(spam$has_dollar)
spam$has_emoticon<-factor(spam$has_emoticon)
spam$has_email<-factor(spam$has_email)
spam$has_phone<-factor(spam$has_phone)

summary(spam)      #just the summary 
spam<-spam

# Step 2: Split data into a training and test set
set.seed(123)
n         <- nrow(spam)
split     <- round(n*0.70) 
train.ind <- sample(1:n, split, replace=FALSE)

spam <- spam[, -which(names(spam) == "id")]     #removing a coloum Id

trainData <- spam[train.ind, ]                  #assigning my training set
testData  <- spam[-train.ind, ]                 #assigning my training set

# Question 2

#we need to fit the logostic model with all the predictor variables


q2a_model <- glm(is_spam ~ .,
                   family = "binomial",
                   data = trainData)
                  
summary(q2a_model)


q2b_model <- glm(is_spam ~ . -has_url -has_date  -has_email -has_phone,
                 family = "binomial",
                 data = trainData)
summary(q2b_model)

# Question 3

#we need to use the bete estimates 

#calculating the predicted probabilities
probs <- predict(q2b_model, newdata = testData, type = "response")
summary(probs)

#converting the predicted probs to factor
threshold  <- 0.5
y_probs_num <- ifelse(probs > threshold, 1, 0) 
pred     <- factor(y_probs_num, levels = c(0,1)) 

#using the confusion Matrix 
y_act      <- testData$is_spam
CM<-confusionMatrix(data = pred, reference = y_act, "1")

# Question 4

#Generated sequence
GenSeq<-seq(0, 1, by = 0.01)
#GenSeq

#Converting probs

recalLNumber4<-numeric(length(GenSeq))
SpecificityNumber4<-numeric(length(GenSeq))
#For loop

for(i in seq_along(GenSeq)){
  
  probs_num <- ifelse(probs >GenSeq[i] , 1, 0) 
  probs_num     <- factor(probs_num)    #factoring my probablities
  #y_act      <- testData$is_spam
 cm<-confusionMatrix(probs_num, testData$is_spam)

 recalLNumber4[i]<-cm$byClass["Sensitivity"]   #list of recall
 SpecificityNumber4[i]<-cm$byClass["Specificity"]
}

#difference between the recalles and specificity
Difference<-recalLNumber4-(1-SpecificityNumber4)

q4<-GenSeq[which.max(Difference)]

#creating dataframe
#DataFrame<-data.frame(Recall = recall, Specificity = Specificity)

#roc curve
#ROC<-roc(Specificity , Recall, data = DataFrame)

#plotting the 
#PLOT(y = DataFrame$Recall, x = (1-DataFrame$Specificity))
#ggplot(DataFrame,aes(x = x <- (1-DataFrame$Specificity), y <-DataFrame$Recall ))+ geom_point()












