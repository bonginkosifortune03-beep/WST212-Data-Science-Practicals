# WST212 Data Science Practicals (2024)

Practicals in **R** for **WST212** at the University of Pretoria: Monte Carlo simulation,
querying relational data with SQL from R, and building a classification model.

## Contents

| Practical | Topic | What is done |
|---|---|---|
| [0](Practical-0_Snakes-and-Ladders-Simulation) | Monte Carlo simulation | Simulating a dice game (with snakes and ladders) many times to estimate the mean and standard deviation of the number of rolls needed to finish |
| [1](Practical-1_SQL-Queries-in-R) | SQL queries in R | Selecting, filtering and sorting supermarket customer, purchase and product tables with `sqldf` |
| [2](Practical-2_SQL-Joins-and-Aggregation) | SQL joins and aggregation | Inner joins across six related tables, `GROUP BY` summaries per branch, year and product line, subqueries and date handling with `lubridate` |
| [4](Practical-4_Spam-Classification) | Spam classification | Logistic regression on SMS message features (contains a URL, number, email and so on), train/test split, variable selection and evaluation with a confusion matrix (`caret`) |

## How to run
1. Set the working directory to the practical's folder, e.g. `setwd("Practical-1_SQL-Queries-in-R")`.
2. Install the packages if needed:
   ```r
   install.packages(c("sqldf", "lubridate", "RH2", "caret"))
   ```
3. Run the script. Each one reads its CSV files from its own folder.

## Author
Tlou (Maima) Bonginkosi Fortune
