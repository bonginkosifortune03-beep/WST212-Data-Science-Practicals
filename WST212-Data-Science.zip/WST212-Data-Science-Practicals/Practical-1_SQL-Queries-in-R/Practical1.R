########################
# Practical 1
# Name and surname: Bonginkosi Fortune Maima
# Student number: u22826093
########################

# Import the necessary packages
# DO NOT IMPORT ANY OTHER PACKAGES
library(sqldf)
library(lubridate)
library(RH2)

# Import the tables
customer_info <- read.csv("customer_info.csv")
customer_purchase_info <- read.csv("customer_purchase_info.csv")
product_sales <- read.csv("product_sales.csv")

# Question 1
Q1<-sqldf("SELECT Customer_Id,Invoice_ID,Product_ID
          FROM customer_purchase_info")

# Question 2
Q2<-sqldf("SELECT *
          FROM customer_info")

# Question 3
Q3<-sqldf("SELECT Customer_Id,Customer_type,Branch,Rating
          FROM customer_purchase_info
          ORDER BY Rating desc")

# Question 4
Q4<-sqldf("SELECT Customer_Id,Invoice_ID,Customer_type,Product_ID,Branch
          FROM customer_purchase_info
          WHERE Payment= 'Credit card' ")

# Question 5
Q5<-sqldf("SELECT Product_ID,Rating,
          CASE
            WHEN Rating>=0 AND Rating <2.5 THEN 'Very Poor'
            WHEN Rating>=2.5 AND Rating <4.5 THEN 'Poor'
            WHEN Rating>=4.5 AND Rating <6 THEN 'Neutral'
            WHEN Rating>=6 AND Rating <8.5 THEN 'Good'
            WHEN Rating>=8.5 AND Rating <=10 THEN 'Very Good'
          END AS Feedback
          FROM customer_purchase_info
          ORDER BY Rating")

# Question 6
Q6<-sqldf("SELECT Invoice_ID,Product_ID,(Total-cogs) AS Profit
          FROM product_sales ")

# Question 7
Q7<-sqldf("SELECT Payment,
         Count(*) AS Count
         FROM customer_purchase_info 
         GROUP BY Payment
         HAVING Count(*)>315")


# Question 8
customer_purchase_info$Purchase_Date<-as.Date(customer_purchase_info$Purchase_Date,
                                  format='%d-%b-%Y')
Q8<-sqldf("SELECT *
         FROM customer_purchase_info 
         WHERE Purchase_Date >='2022-01-05' AND Purchase_Date <='2022-02-26' AND Customer_type='Member' ")




# Question 9


#Setting the 
#customer_info$Current<-as.Date('2024-03-03')

customer_info$Customer_birth<-as.Date(customer_info$Customer_birth,
                                              format='%d-%b-%Y')
customer_info$Current<-as.Date('2024-03-03')


Q9<-sqldf("SELECT Customer_name,Customer_contact,Customer_birth,
         floor((Current-Customer_birth)/365) AS Age
          FROM customer_info
          WHERE floor((Current-Customer_birth)/365)>=60
          ") 



# Question 10

customer_info$Customer_birth<-as.Date(customer_info$Customer_birth,format="%d-%b-%Y")

Q10<-sqldf("SELECT Customer_name,Customer_contact,
            month(Customer_birth) as month,
            year(Customer_birth) as year
            FROM customer_info
            Where month(Customer_birth) = '4' ") 
