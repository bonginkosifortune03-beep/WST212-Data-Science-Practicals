#we need to simulate a rolling of a 6 sided die



set.seed(19) #to get same results all the time on the frequncey table
nsim<-10000;     #Number of simulations
#we then need to create a vector which will specifies the lenght of our simulation
SNL<-vector(mode="integer" ,length = nsim) #this specifies the length of our vector/number of rolls

#we then use the for loop for us to loop in our simulation
for(i in 1:nsim)
#inside here we put our simulation of the code
#we use a while loop for our simulation to repeate 36 times
#we need to have variable of sum and y
  y<-0                  #its starts from zero
  sum_x<-0
  
  while(sum_x<36)       #we use a while loop for our simulation to repeate 36 times
  {
    x<-sample(1:6, size=1, replace=TRUE)#this we need to have replacement with it
    sum_x <- sum_x + x      #then after every simulation we add sum to x
    y <- y + 1              #number of roll  of a  die 
    sum_x<-if(sum_x==5) 18 else sum_x  #for the ledder and snake
    sum_x<-if(sum_x==9) 3 else sum_x
    sum_x<-if(sum_x==10) 15 else sum_x
    sum_x<-if(sum_x==14) 2 else sum_x
    sum_x<-if(sum_x==16) 7 else sum_x
    sum_x<-if(sum_x==19) 32 else sum_x
    sum_x<-if(sum_x==27) 33 else sum_x
    sum_x<-if(sum_x==28) 15 else sum_x
    sum_x<-if(sum_x==35) 13 else sum_x
  }
  SNL[i] <- y
}
table(SNL)
plot(table(SNL),main = "Plot",xlab = "Number of roll of a die", ylab = "Counts") #plot
summary(SNL) #fIVE NUMBER SUMMARY
mean(SNL)