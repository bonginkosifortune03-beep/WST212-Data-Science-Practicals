########################
# Practical 0
# Name and surname: Maima Bonginkosi Fortune
# Student number:u22826093
########################

# Question 1
Q1<-36/12     #minimum value of Y


#Question 2 

#Set a seed
set.seed(13)
Nsim=1   #Number of simulation
SNL<-vector(mode="integer" ,length = Nsim) #number of rolls

#we then use the for loop for us to loop in our simulation
for(i in 1:Nsim){
  y<-0                  #its starts from zero
  sum_x<-0
  while(sum_x<36)       #we use a while loop for our simulation to repeate 36 times
  {
    x<-sample(1:12, size=1, replace=TRUE)#this we need to have replacement with it
    sum_x <- sum_x + x      #then after every simulation we add sum to x
    y <- y + 1              #number of roll  of a  die 
  }
  SNL[i] <- y
}
Q2<-y  #number of rolls needed to complete the game



# Question 3

#Set a seed
set.seed(7)
Nsim=10000   #Number of simulation
Q3<-vector(mode="integer" ,length = Nsim) #vector number of rolls

#we then use the for loop for us to loop in our simulation
for(i in 1:Nsim){
  y<-0                  #its starts from zero
  sum_x<-0
  while(sum_x<36)       #we use a while loop for our simulation to repeate 36 times
  {
    x<-sample(1:12, size=1, replace=TRUE)#this we need to have replacement with it
    sum_x <- sum_x + x      #then after every simulation we add sum to x
    y <- y + 1              #number of roll  of a  die 
  }
  Q3[i] <- y
}

Q3a<-mean(Q3) #the mean value of number of rolls needed to complete the game
#summary(y)
Q3b<-sd(Q3)   #standard deviation
barplot(table(Q3),main = "Plot",xlab = "Number of roll of a die", ylab = "Counts") #plot

#Question 4
#Set a seed
set.seed(20)
Nsim=1   #Number of simulation
Q31<-vector(mode="integer" ,length = Nsim) #vector number of rolls

#we then use the for loop for us to loop in our simulation
for(i in 1:Nsim){
  y<-0                  #its starts from zero
  sum_x<-0
  while(sum_x<36)       #we use a while loop for our simulation to repeate 36 times
  {
    x<-sample(1:12, size=1, replace=TRUE)#this we need to have replacement with it
    sum_x <- sum_x + x      #then after every simulation we add sum to x
    y <- y + 1              #number of roll  of a  die 
    sum_x<-if(sum_x==5) 18 else sum_x  #for the ledder and snake
    sum_x<-if(sum_x==9) 3 else sum_x
    sum_x<-if(sum_x==10) 15 else sum_x
    sum_x<-if(sum_x==14) 2 else sum_x
    sum_x<-if(sum_x==16) 7 else sum_x
    sum_x<-if(sum_x==19) 32 else sum_x
    sum_x<-if(sum_x==27) 33 else sum_x
    sum_x<-if(sum_x==28) 15 else sum_x
    sum_x<-if(sum_x==35) 13 else sum_x
  }
  Q31[i] <- y
}
Q4<-Q31  #Number of rolls need to complete the game


#Question 5
#Set a seed
set.seed(13)
Nsim=1   #Number of simulation
SNL<-vector(mode="integer" ,length = Nsim) #number of rolls

#we then use the for loop for us to loop in our simulation
for(i in 1:Nsim){
  y<-0                  #its starts from zero
  sum_x<-0
  while(sum_x<36)       #we use a while loop for our simulation to repeate 36 times
  {
    x<-sample(1:12, size=1, replace=TRUE)#this we need to have replacement with it
    sum_x <- sum_x + x      #then after every simulation we add sum to x
    y <- y + 1              #number of roll  of a  die 
  }
  SNL[i] <- y
}
Q2<-y  #number of rolls needed to complete the game



# Question 3

#Set a seed
set.seed(81)
Nsim=10000   #Number of simulation
Q5<-vector(mode="integer" ,length = Nsim) #vector number of rolls

#we then use the for loop for us to loop in our simulation
for(i in 1:Nsim){
  y<-0                  #its starts from zero
  sum_x<-0
  while(sum_x<36)       #we use a while loop for our simulation to repeate 36 times
  {
    x<-sample(1:12, size=1, replace=TRUE)#this we need to have replacement with it
    sum_x <- sum_x + x      #then after every simulation we add sum to x
    y <- y + 1              #number of roll  of a  die 
    sum_x<-if(sum_x==5) 18 else sum_x  #for the ledder and snake
    sum_x<-if(sum_x==9) 3 else sum_x
    sum_x<-if(sum_x==10) 15 else sum_x
    sum_x<-if(sum_x==14) 2 else sum_x
    sum_x<-if(sum_x==16) 7 else sum_x
    sum_x<-if(sum_x==19) 32 else sum_x
    sum_x<-if(sum_x==27) 33 else sum_x
    sum_x<-if(sum_x==28) 15 else sum_x
    sum_x<-if(sum_x==35) 13 else sum_x
  }
  Q5[i] <- y
}

Q5a<-mean(Q5) #the mean value of number of rolls needed to complete the game
#summary(y)
Q5b<-sd(Q5) 
barplot(table(Q5),main = "Plot",xlab = "Number of roll of a die", ylab = "Counts") #plot