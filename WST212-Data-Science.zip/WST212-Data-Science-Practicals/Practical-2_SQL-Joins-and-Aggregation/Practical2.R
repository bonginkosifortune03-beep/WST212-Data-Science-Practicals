########################
# Practical 2
# Name and surname: Maima Bonginkosi Fortune
# Student number: u22826093
########################

# Import the necessary packages
# DO NOT IMPORT ANY OTHER PACKAGES
library(sqldf)
library(lubridate)
library(RH2)

# Import the tables
customer_info <- read.csv("customer_info.csv")
customer_purchase_ctc <- read.csv("customer_purchase_ctc.csv")
customer_purchase_info <- read.csv("customer_purchase_info.csv")
employee_purchase_info <- read.csv("employee_purchase_info.csv")
product_description <- read.csv("product_description.csv")
product_sales <- read.csv("product_sales.csv")


# Question 1
customer_purchase_info$Purchase_Date=as.Date(customer_purchase_info$Purchase_Date,
                                             format('%d-%b-%Y'))
Q1<-sqldf("SELECT
          a.Branch ,
          YEAR(a.Purchase_Date) AS Year,
          SUM(b.Total) AS Amount
          FROM customer_purchase_info as a
          INNER JOIN product_sales as b
          on a.Invoice_ID = b.Invoice_ID
          GROUP BY a.Branch,Year
          ORDER BY a.Branch,Year;
          ")

# Question 2
Q2<-sqldf("SELECT
          a.Product_line AS Category,
          SUM(b.Quantity) AS Total
          FROM customer_purchase_ctc as b
          INNER JOIN product_description as a
          ON a.Product_ID=b.Product_ID
          GROUP BY  a.Product_line; ")

# Question 3
Q3<-sqldf("SELECT
          a.Branch,
          b.Product_line AS Category,
          SUM((c.Quantity*c.Unit_Price)+c.Tax) AS Invoice_Amount
          FROM customer_purchase_ctc as c
          inner join product_description as b
          on c.Product_ID= b.Product_ID
          inner join customer_purchase_info as a
          on c.Invoice_ID=a.Invoice_ID
          GROUP BY a.Branch,Category
          ORDER BY a.Branch;")

# Question 4
Q4<-sqldf("SELECT
          Invoice_ID,Product_ID 
          FROM product_sales
          WHERE (Total-cogs) < (SELECT AVG(Total-cogs) FROM product_sales)")

# Question 5
Q5<-sqldf("SELECT 
          a.Customer_id
          FROM customer_purchase_info as a
          inner join employee_purchase_info as b
          on a.Customer_id=b.Customer_id
          WHERE a.Branch='A' ")

# Question 6
#customer_info$Customer_birth=as.Date(customer_info$Customer_birth,
#                                     format('%d-%b-%Y'))  

Q6<-sqldf("SELECT
          Customer_name,
          Customer_birth
          FROM customer_info 
          WHERE Customer_id IN (SELECT 
          a.Customer_id
          FROM customer_purchase_info as a
          inner join employee_purchase_info as b
          on a.Customer_id=b.Customer_id
          WHERE a.Branch='A' )")
